CREATE VIEW v_book_user AS
  SELECT
    `b`.`bookname` AS `bookname`,
    `u`.`id`       AS `id`,
    `u`.`name`     AS `name`,
    `u`.`password` AS `password`
  FROM `test`.`t_book` `b`
    JOIN `test`.`t_user` `u`
  WHERE (`b`.`uid` = `u`.`id`);
