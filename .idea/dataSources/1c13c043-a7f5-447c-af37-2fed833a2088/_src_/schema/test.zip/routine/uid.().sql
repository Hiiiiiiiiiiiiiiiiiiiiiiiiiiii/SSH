CREATE PROCEDURE uid(OUT ids INT)
  BEGIN
	select COUNT(*) into ids from t_user where id = 1;

END;
