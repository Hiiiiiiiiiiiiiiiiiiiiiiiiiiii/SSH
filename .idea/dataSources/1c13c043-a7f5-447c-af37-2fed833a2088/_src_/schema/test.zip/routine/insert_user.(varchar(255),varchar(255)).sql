CREATE PROCEDURE insert_user(IN newname VARCHAR(255), IN newpassword VARCHAR(255))
  BEGIN
	insert into t_user (name,password) values (newname,newpassword);

END;
