CREATE PROCEDURE save()
  BEGIN
	select * from t_user where id = '1';

END;
